# Agent Control Tower - Task / Execution Plan

## Read This First

We are using Claude Code and building vertically. The schedule is not a feature-tier commitment. It is a sequence of versions. If a version is complete, tested, and stable, move to the next one. If time becomes tight, stop at the latest reliable version rather than creating a half-built later version.

## Version Execution Loop

For every version:

1. Read the relevant PRD, Build Map, Technical Spec, Design Spec, and Test Plan sections.
2. Inspect the existing implementation before changing it.
3. Implement only the current version.
4. Run unit/integration tests.
5. Run a real end-to-end experiment with Entire where applicable.
6. Review the diff and Graph before risky changes.
7. Create/verify the Entire Checkpoint.
8. Record what changed and what remains for the next version.
9. Only then begin the next version.

## V0 - Foundation

**Goal:** runnable development environment.

Tasks:
- initialize frontend/backend;
- configure Claude Code workflow;
- install/configure Entire CLI;
- enable Entire Checkpoints;
- establish test runner;
- verify local startup.

Done when the app runs and the Entire workflow is usable.

## V1 - Single Agent Control Tower

**Goal:** one real agent appears from checkpoint data.

Tasks:
- checkpoint collector;
- parser/normalizer;
- agent registry;
- live event endpoint;
- Agent World;
- Agent Node;
- basic status display.

Done when a real Claude Code task creates a checkpoint visible in the UI.

## V2 - Agent Inspection

Tasks:
- clickable agent;
- details panel;
- objective/prompt;
- files;
- tool activity;
- commits;
- checkpoint list.

Done when the complete observable agent context is inspectable.

## V3 - LLM Understanding

Tasks:
- commit explainer;
- accomplishment summary;
- intent-vs-actual analysis;
- evidence formatting and guardrails.

Done when explanations are grounded in real checkpoint data.

## V4 - Status Intelligence

Tasks:
- status engine;
- ON TRACK/STUCK/DONE;
- DRIFTING if useful;
- status evidence and failure states.

Done when a judge can ask "why is this agent stuck?" and see evidence.

## V5 - Entire Graph Intelligence

Tasks:
- Graph client;
- investigation flow;
- blast-radius extraction;
- Graph-backed diagnosis;
- use Graph before risky changes;
- semantic-diff review before finalizing changes.

Done when structural diagnosis contains an actual Graph relationship.

## V6 - Handoff

Tasks:
- handoff service;
- continuation prompt;
- blocker/evidence/Graph impact/next action;
- copyable UI.

Done when a fresh agent can receive a useful continuation context.

## V7 - Reconstruction ⭐

Tasks:
- checkpoint selector;
- historical cutoff logic;
- state reconstruction;
- future-context filter;
- reconstruction prompt formatter;
- reconstruction UI;
- `UNVERIFIED` label.

Done when a selected real checkpoint produces a self-contained prompt with no later-checkpoint information.

## V8 - Two-Agent Live World

Tasks:
- run two sessions;
- register both;
- update both live;
- switch between agents;
- verify isolation of histories.

Done when parallel supervision is convincing.

## V9 - Collision Detection

Tasks:
- compare touched files/functions;
- query Graph relationships;
- create conflict model;
- warning UI;
- reproduce a controlled collision for the demo.

## V10 - Evidence / Trust

Tasks:
- deterministic evidence score;
- checkpoint completeness;
- Graph verification;
- test result contribution;
- transparent breakdown UI.

## V11 - Timeline

Tasks:
- checkpoint timeline;
- checkpoint selection;
- connect selected state to inspection/reconstruction.

## V12 - Databricks Historical Memory

Tasks:
- persist allowed checkpoint-derived data;
- historical retrieval;
- meaningful aggregate metric;
- failure/fallback behavior;
- demonstrate Databricks materially changes product behavior.

## V13 - Reconstruction Verification

Tasks:
- launch fresh agent from generated prompt;
- compare state with source checkpoint;
- report fidelity.

## V14 - Replay

Tasks:
- one-click fresh session;
- replay selected checkpoint;
- capture resulting checkpoint/diff.

## Noon Curveball

The curveball is not a separate feature version. It is a mandatory validation event that must happen in a fresh agent session using the earlier checkpoint context and Graph analysis.

Required sequence:

```text
Stable pre-noon version
        ↓
Entire Checkpoint
        ↓
Fresh Claude Code session
        ↓
Recover context from checkpoint
        ↓
Use Entire Graph for investigation/impact analysis
        ↓
Implement smallest complete response
        ↓
Test
        ↓
New checkpoint
```

## Hard Rules

1. Never sacrifice a working version just to start a later one.
2. Reconstruction is a hero feature, not a leftover stretch feature.
3. The Control Tower and Reconstruction are the two product pillars.
4. Handoff connects observation to continuation.
5. Entire Checkpoint data must be real product input.
6. Graph evidence must be real where a claim depends on structure.
7. Future versions are allowed to be unfinished; unfinished current versions are not.
