# Agent Control Tower - Demo Script

## Target Length

Aim for 3-5 minutes. Demonstrate the highest **completed and reliable version**. Never narrate a future version as if it shipped.

## Narrative

> "When multiple AI coding agents work in parallel, the hard problem isn't getting code generated. It's knowing what actually happened, whether the work is healthy, and how to recover a useful state when it isn't. Agent Control Tower uses Entire Checkpoints as evidence and Entire Graph as structural context to supervise and recover that work."

## Scene 1 - Live Control Tower

Show the live Agent World.

> "These agents are not mocked activity cards. Their state is derived from Entire Checkpoints."

Show objective, activity, latest checkpoint, and status.

## Scene 2 - Inspect an Agent

Click an agent.

Show:
- original objective;
- current activity;
- files;
- commits;
- checkpoint trail.

> "We can move from a high-level view into the actual checkpoint evidence behind the agent."

## Scene 3 - Understand a Commit

Open a commit explanation.

> "The LLM explains the commit, but it is constrained by the checkpoint evidence. It isn't inventing a story about the code."

## Scene 4 - Diagnose a Stuck Agent

Select a reproducibly stuck agent.

Show status and evidence.

Then show Graph relationship/blast radius.

> "The important part is that the diagnosis isn't just an LLM opinion. Entire Graph gives us the structural impact."

## Scene 5 - Handoff

Generate the continuation prompt.

> "If this agent is stuck, we don't just report the problem. We produce a checkpoint-grounded handoff another agent can continue from."

## Scene 6 - Checkpoint Reconstruction ⭐ Hero Beat

Select an earlier checkpoint.

Click:
`RECONSTRUCT THIS CHECKPOINT`

Show:
- stack;
- project structure;
- decision log;
- current state;
- `FUTURE CONTEXT FILTERED`.

Generate the prompt.

> "This is the second half of the product. A checkpoint isn't merely a log entry. We treat it as a recoverable development state. We can generate a self-contained prompt that recreates the project context up to this exact point without leaking information from the future."

Point to `UNVERIFIED`.

> "We label this unverified until we add replay and fidelity measurement."

## Scene 7 - Two Agents / Collision (if completed)

Show two agents touching related code and the Graph relationship.

> "Once multiple agents are live, the same evidence lets us detect when their work starts converging on related code."

## Scene 8 - Databricks (if completed)

Show historical retrieval/aggregate only if the implementation is actually live.

> "Databricks adds historical memory to the product, using real checkpoint-derived data rather than a superficial integration."

## Scene 9 - Noon Curveball

Show the stable pre-noon checkpoint and fresh Claude Code session.

> "At noon, we deliberately started a fresh session from earlier checkpoint context, investigated the impact with Graph, implemented the smallest complete response, and captured the new state."

## Closing

> "Agent Control Tower turns AI coding sessions into observable, explainable, recoverable development states. Entire tells us what happened. Graph tells us how the code is connected. The Control Tower helps us understand it, continue it, or reconstruct it."

## Demo Rule

The demo should always use the highest stable version actually implemented. A smaller working vertical slice is stronger than a larger sequence of broken promises.
