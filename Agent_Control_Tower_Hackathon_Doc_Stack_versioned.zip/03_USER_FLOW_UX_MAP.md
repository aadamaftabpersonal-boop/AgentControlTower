# Agent Control Tower - User Flow / UX Map

## 1. Product Flow

```text
Entire Checkpoint
       ↓
Live Agent Appears
       ↓
Inspect Agent
       ↓
Understand Work
       ↓
Graph-backed Diagnosis
       ↓
Recover / Continue
       │
       ├── Handoff → Fresh Agent continues
       │
       └── Reconstruction → Fresh Agent recreates selected checkpoint state
```

The last two are distinct recovery modes. Handoff continues the current line of work. Reconstruction recreates a historical state from scratch.

## 2. Main Happy Path

1. Open Control Tower.
2. See agent(s) appear from real Entire checkpoint events.
3. Click an agent.
4. Inspect objective, activity, files, commits, and checkpoint trail.
5. Open a commit and request LLM explanation.
6. Run analysis when the agent appears stuck or off-track.
7. See Graph-backed evidence.
8. Generate a handoff if continuation is needed.
9. Select a checkpoint and choose `RECONSTRUCT THIS CHECKPOINT` when historical recovery is needed.

## 3. Reconstruction Flow ⭐

```text
Checkpoint list
      ↓
Select checkpoint
      ↓
Checkpoint Inspector
      ↓
RECONSTRUCT THIS CHECKPOINT
      ↓
Reconstruction Context
      ↓
Future Context Filtered
      ↓
Generate Reconstruction Prompt
      ↓
Copy prompt
      ↓
Fresh Claude Code session
```

The reconstruction screen should show:
- Original objective
- Project structure
- Files/changes
- Decisions and assumptions
- Dependencies
- Current state
- `FUTURE CONTEXT FILTERED`
- `UNVERIFIED` warning until replay verification exists

## 4. Handoff Flow

```text
STUCK
 ↓
Why?
 ↓
Checkpoint evidence + Graph impact
 ↓
Generate Handoff
 ↓
Copy continuation prompt
 ↓
Fresh agent
```

## 5. Multi-Agent Flow

```text
Agent A ── checkpoint ──┐
                        ├──→ Control Tower
Agent B ── checkpoint ──┘
```

Later, Graph relationships can connect both agents' touched code and trigger a collision warning.

## 6. Error Paths

### No new checkpoint
Show `WAITING FOR AGENT ACTIVITY`.

### Incomplete checkpoint
Show `INSUFFICIENT EVIDENCE` and explain which evidence is missing.

### LLM failure
Show `LLM EXPLANATION UNAVAILABLE` and preserve raw evidence.

### Graph unavailable
Show `GRAPH EVIDENCE UNAVAILABLE` and disable Graph-dependent diagnosis/conflict claims.

### Reconstruction has no sufficient history
Show `INSUFFICIENT RECONSTRUCTION CONTEXT` rather than fabricating missing state.

### Reconstruction verification unavailable
Show `UNVERIFIED`. Do not claim replay fidelity.

## 7. Version-Aware UX

V1 should feel useful with one live agent. V2 adds depth. V3/V4 add understanding. V5/V6 add diagnosis and recovery. V7 introduces the second hero pillar. V8+ expand the world rather than replace earlier flows.
