# Agent Control Tower - Technical Specification

## 1. Architecture Principle

The system is developed version by version with Claude Code. Each version extends the previous implementation without breaking it.

## 2. Tech Stack

### Frontend
- React
- TypeScript
- Vite
- CSS modules or Tailwind CSS
- SSE client

### Backend
- Python
- FastAPI
- Git/Entire CLI integration
- Local runtime state for live operation

### AI
- LLM for interpretation and generation only.
- Deterministic parsers and evidence models remain authoritative.

### Source of Truth

Entire Checkpoints are the factual source of truth for agent prompts, transcripts, files, tool calls, commits, timestamps, and checkpoint identity. Entire Graph is the structural source for code relationships and impact analysis.

## 3. Architecture Decisions

### Checkpoint-native
No major product claim should depend on invented or synthetic agent history when real checkpoint evidence is available.

### Deterministic facts before LLM interpretation
The pipeline is:

```text
Entire evidence
    ↓
Normalize facts
    ↓
Select evidence
    ↓
LLM interpretation
    ↓
Structured result + evidence
```

### Graph is first-class evidence
Stuck diagnosis, impact analysis, and collision detection should carry concrete Graph relationships. Graph is not just a visualization.

### SSE before WebSockets
SSE is sufficient for the live event stream and simpler to debug within the hackathon.

### Local live state first
Current live agent state remains simple. Databricks is introduced only when its historical retrieval/analytics actually improves product behavior.

## 4. Core Data Model

### Agent

- `agent_id`
- `session_id`
- `name`
- `role`
- `objective`
- `status`
- `current_activity`
- `current_files`
- `latest_checkpoint_id`
- `commit_ids`
- `created_at`
- `updated_at`

### Checkpoint

- `checkpoint_id`
- `agent_id`
- `session_id`
- `timestamp`
- `prompt`
- `transcript`
- `files_touched`
- `functions_touched`
- `tool_calls`
- `commits`
- `tests`
- `metadata`

### Analysis

- `agent_id`
- `checkpoint_id`
- `summary`
- `intent_relationship`
- `status`
- `reason`
- `evidence`
- `graph_blast_radius`

### Handoff

- `agent_id`
- `checkpoint_id`
- `objective`
- `current_state`
- `blocker`
- `evidence`
- `graph_impact`
- `next_action`
- `prompt`

### Reconstruction

- `checkpoint_id`
- `cutoff_timestamp`
- `stack`
- `dependencies`
- `project_structure`
- `decision_log`
- `current_state`
- `excluded_future_context`
- `prompt`
- `verification_status`

## 5. Reconstruction Contract ⭐

`POST /api/checkpoints/{checkpoint_id}/reconstruction-prompt`

Algorithm:

1. Load selected checkpoint.
2. Load all valid earlier checkpoints for the same session/history.
3. Establish a hard chronological cutoff.
4. Extract stack/dependencies known by that point.
5. Reconstruct file/directory structure from evidence available by that point.
6. Serialize decisions, assumptions, and rejected alternatives supported by evidence.
7. Describe the current state at the checkpoint.
8. Explicitly exclude facts first introduced after the selected checkpoint.
9. Generate one self-contained prompt for a fresh coding-agent session.
10. Mark output `UNVERIFIED` until V13 replay/fidelity verification exists.

**Critical invariant:** no later-checkpoint fact may enter the reconstruction prompt.

## 6. LLM Contracts

LLM may:
- summarize evidence;
- explain commits;
- compare intent with observed work;
- diagnose status from supplied evidence;
- generate handoff text;
- format reconstruction context into a coding-agent prompt.

LLM may not:
- invent files, commits, tests, Graph relationships, timestamps, or checkpoint history;
- silently use later checkpoints in a historical reconstruction;
- convert uncertainty into certainty.

## 7. Version-to-Architecture Mapping

- V0: application foundation and Entire setup.
- V1: checkpoint ingestion + live state.
- V2: inspection APIs/UI.
- V3: LLM analysis layer.
- V4: status engine.
- V5: Graph service and blast radius.
- V6: handoff service.
- V7: reconstruction service.
- V8: multi-agent registry/live updates.
- V9: conflict service.
- V10: deterministic evidence score.
- V11: timeline.
- V12: Databricks service.
- V13: fidelity runner.
- V14: replay service.

## 8. Failure Philosophy

- Missing checkpoint: `WAITING FOR AGENT ACTIVITY`.
- Incomplete evidence: `INSUFFICIENT EVIDENCE`.
- LLM failure: `LLM EXPLANATION UNAVAILABLE`.
- Graph unavailable: `GRAPH EVIDENCE UNAVAILABLE` and disable Graph-dependent conclusions.
- Reconstruction verification unavailable: show `UNVERIFIED`.
- Databricks unavailable in later versions: historical-memory features degrade explicitly rather than silently pretending they worked.
