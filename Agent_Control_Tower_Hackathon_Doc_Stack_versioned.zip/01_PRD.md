# Agent Control Tower - Product Requirements Document

## 1. Product

Agent Control Tower is a live, checkpoint-native developer experience for supervising multiple AI coding agents. It turns the evidence captured by Entire into a visual control room for understanding intent, actual work, progress, failures, recovery, and reproducible development states.

The system does not treat an LLM as the source of truth. **Entire Checkpoints provide factual evidence; Entire Graph provides structural evidence; the LLM interprets that evidence.**

## 2. Target User

Developers, technical leads, and hackathon teams running multiple AI coding agents in parallel.

## 3. Problem

Parallel coding agents create a supervision problem:

- What is each agent actually doing?
- Is the work aligned with its original objective?
- Is an agent stuck or simply taking a long step?
- What did a commit actually accomplish?
- Are two agents modifying related code?
- If an agent fails, how can another agent continue?
- How can we recreate the project state that existed at a known checkpoint?

## 4. Core Product Principles

1. **Checkpoint-native** - actual Entire Checkpoint context is essential input.
2. **Evidence before interpretation** - deterministic facts are extracted before LLM analysis.
3. **Graph-backed reasoning** - structural claims are verified through Entire Graph where possible.
4. **Vertical scaling** - each release is a complete working version.
5. **Recoverability** - a checkpoint is treated as a recoverable state, not merely a log entry.
6. **Honest uncertainty** - unsupported conclusions are shown as unavailable or unverified.

## 5. Version Roadmap

The project is built as a sequence of vertical slices. The exact stopping point is allowed to change based on implementation speed, but the order should remain coherent.

### V0 - Foundation

- Repository structure
- Frontend and backend shells
- Claude Code development workflow
- Entire CLI setup
- Entire Checkpoints enabled
- Environment/configuration
- Basic automated test setup

**Done when:** the application runs locally and the Entire workflow is verified.

### V1 - Single Agent Control Tower

- Real Entire Checkpoint ingestion
- Checkpoint parser and normalized model
- Agent registry/state
- Control Tower dashboard
- One live Agent Node
- Objective, status placeholder, current activity, latest checkpoint

**Done when:** a real Claude Code session creates a checkpoint that appears in the dashboard.

### V2 - Agent Inspection

- Clickable Agent Node
- Agent detail panel
- Original prompt/objective
- Files touched
- Tool activity
- Commits
- Checkpoint trail/list

**Done when:** a user can inspect an agent without leaving the Control Tower.

### V3 - LLM Understanding

- Commit explanation
- Agent accomplishment summary
- Intent-vs-actual analysis
- Evidence references in every explanation

**Done when:** the LLM explains real checkpoint evidence and cannot invent unsupported facts.

### V4 - Status Intelligence

- ON TRACK
- STUCK
- DONE
- DRIFTING when useful
- Evidence-backed status reasons

**Done when:** status changes are explainable from checkpoint evidence and tests.

### V5 - Entire Graph Intelligence

- Graph client
- Investigation of affected code paths
- Blast-radius analysis
- Graph-backed stuck diagnosis
- Semantic-diff review as a team workflow before risky changes

**Done when:** a diagnosis can show a concrete Graph relationship rather than only an LLM opinion.

### V6 - Handoff

- Handoff generator
- Checkpoint-grounded continuation prompt
- Current state, blocker, evidence, Graph impact, and next action

**Done when:** a second agent can receive a useful prompt without manually reconstructing the first agent's context.

### V7 - Checkpoint Reconstruction ⭐ Hero Feature

- Select a checkpoint
- Gather only that agent/session's checkpoint history up to the selected point
- Reconstruct stack/dependencies
- Reconstruct file/directory structure
- Reconstruct decisions, assumptions, and rejected alternatives
- Reconstruct current state
- Strictly filter information first appearing in later checkpoints
- Generate a self-contained coding-agent prompt
- Label output **UNVERIFIED** until replay fidelity exists

**Core claim:** **A checkpoint is a recoverable state of development.**

**Done when:** selecting a real checkpoint produces a coherent reconstruction prompt that contains no future-checkpoint information.

### V8 - Two-Agent Live World

- Two concurrent agent sessions
- Live updates for both
- Agent switching
- Cross-agent state visibility

**Done when:** the Control Tower convincingly demonstrates parallel work.

### V9 - Agent Collision Detection

- Compare files/functions touched by agents
- Use Graph relationships to detect related execution paths
- Show exact relationship in conflict warning

**Done when:** a reproducible demo can trigger a real or controlled Graph-backed collision.

### V10 - Evidence / Trust Layer

- Deterministic evidence score
- Checkpoint completeness
- Graph verification
- Test pass rate
- Transparent breakdown

**Done when:** the score is explainable and never an LLM guess.

### V11 - Checkpoint Timeline

- Interactive checkpoint timeline
- Step through historical project states
- Connect timeline state directly to reconstruction

### V12 - Databricks Historical Memory

- Persist checkpoint-derived historical data
- Retrieve similar historical situations
- Surface aggregate cross-session insights
- Demonstrate meaningful Databricks contribution

### V13 - Reconstruction Verification

- Generate reconstruction prompt
- Run a fresh agent
- Compare reconstructed state with the original checkpoint
- Report fidelity metrics

### V14 - Replay

- One-click fresh-session replay from a checkpoint
- Reproduce a checkpoint state from generated context

### V15+ - Research Extensions

Potential directions include checkpoint delta-mode, conceptual checkpoint diffs, richer historical analytics, automated recovery, and larger multi-agent coordination. These should be driven by findings from the previous versions rather than treated as mandatory hackathon scope.

## 6. Definition of a Good Version

Every version should:

1. Run.
2. Preserve previous functionality.
3. Add one coherent capability.
4. Have automated tests where practical.
5. Be tested against real or controlled Entire evidence.
6. Be demonstrable.
7. Leave a clear checkpoint for the next version.

## 7. Hackathon Success Criteria

The strongest practical stopping point is the highest completed version that remains reliable. At minimum, the demo should establish:

- Entire Checkpoints are real product input.
- A live agent can be observed.
- Agent intent and actual work can be inspected.
- At least one LLM explanation is evidence-grounded.
- Entire Graph is used for structural diagnosis.
- A stuck agent can generate a useful handoff.
- The Reconstruction Prompt Generator works from a real checkpoint.
- The Noon Curveball is handled from earlier checkpoint context in a fresh session.

## 8. Constraints

- Work begins only after the official hackathon start.
- Use the required Entire workflow and mirror/fork setup.
- Preserve pre-noon stable state and the curveball response.
- Use public, synthetic, or team-owned data only.
- Do not claim fidelity or historical retrieval unless actually implemented and tested.
