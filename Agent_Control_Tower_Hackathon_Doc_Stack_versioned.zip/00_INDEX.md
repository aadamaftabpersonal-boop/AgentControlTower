# Agent Control Tower - Hackathon Doc Stack

This document stack defines the product, architecture, UX, implementation workflow, testing strategy, demo, and submission story for Agent Control Tower.

## Core Development Philosophy

We are building this project with **Claude Code** using **vertical scaling through working versions**, not a tiered feature backlog.

Every version should be a complete, runnable improvement over the previous version:

```text
Version N
   ↓
Implement one coherent capability
   ↓
Run tests
   ↓
Run a real end-to-end experiment
   ↓
Checkpoint / review
   ↓
Version N+1
```

This means we can stop at any completed version and still have a usable product. We do not need to predict exactly how far the hackathon will take us.

## Documents

1. `01_PRD.md` - Product requirements and version roadmap
2. `02_BUILD_MAP.md` - Architecture and implementation blueprint
3. `03_USER_FLOW_UX_MAP.md` - User flows and interaction model
4. `04_TECHNICAL_SPEC.md` - Technical contracts and architecture decisions
5. `05_TASK_EXECUTION_PLAN.md` - Version-by-version execution plan for Claude Code
6. `06_DESIGN_SPEC_UI_SYSTEM.md` - Visual and interaction system
7. `07_TEST_PLAN.md` - Functional, integration, Graph, reconstruction, and curveball tests
8. `08_DEMO_SCRIPT.md` - Demo narrative and version-aware scenes
9. `09_README_SUBMISSION.md` - Submission-ready README structure
10. `10_VERSION_ROADMAP.md` - Canonical vertical-scaling roadmap

## Product North Star

Agent Control Tower is a checkpoint-native control room for supervising AI coding agents. It uses **Entire Checkpoints as the source of truth** and **Entire Graph as structural evidence** to help a developer understand what agents are doing, detect problems, recover work, and reconstruct a known development state.

### Two hero features

1. **Live Agent Control Tower** - See multiple coding agents, their objectives, activity, status, checkpoints, commits, and evidence in one visual control room.
2. **Checkpoint Reconstruction** - Treat a checkpoint as a recoverable development state and generate a self-contained prompt that recreates the project context up to that exact checkpoint, while filtering out future information.

**Handoff** connects the two: a stuck agent can produce a checkpoint-grounded continuation prompt, while reconstruction can create a fresh starting point from an earlier known state.

## Versioning Rule

Do not build by asking Claude Code to implement the entire roadmap at once. Give Claude Code one version at a time. Each version must preserve previous functionality, add its own tests, and finish in a runnable state before the next version starts.
