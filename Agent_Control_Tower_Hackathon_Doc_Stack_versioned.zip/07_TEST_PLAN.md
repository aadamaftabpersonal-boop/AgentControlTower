# Agent Control Tower - Test Plan

## 1. Testing Philosophy

Every version must leave the application runnable. Tests grow with the version sequence. Do not postpone validation until the end.

## 2. Version Tests

### V0 - Foundation
- [ ] Frontend starts.
- [ ] Backend starts.
- [ ] Entire CLI is available.
- [ ] Entire Checkpoints are enabled.
- [ ] Test runner executes.

### V1 - Single Agent
- [ ] Real checkpoint can be collected.
- [ ] Checkpoint parses into normalized fields.
- [ ] Agent state is created.
- [ ] Agent appears in UI.
- [ ] Live update reaches UI.

### V2 - Inspection
- [ ] Agent details load.
- [ ] Prompt/objective matches checkpoint.
- [ ] Files and commits match source evidence.
- [ ] Checkpoint trail is ordered correctly.

### V3 - LLM Understanding
- [ ] Commit explanation uses supplied evidence.
- [ ] Intent-vs-actual does not invent missing work.
- [ ] LLM failure leaves raw evidence usable.

### V4 - Status
- [ ] ON TRACK is reproducible.
- [ ] STUCK is reproducible.
- [ ] DONE is reproducible.
- [ ] DRIFTING, if implemented, has evidence.

### V5 - Graph
- [ ] Graph relationship can be retrieved.
- [ ] Blast radius contains actual nodes/edges.
- [ ] Stuck diagnosis references Graph evidence.
- [ ] Graph failure disables Graph-dependent claims.

### V6 - Handoff
- [ ] Handoff contains real objective/state/blocker.
- [ ] Handoff references checkpoint evidence.
- [ ] Graph impact is included when available.
- [ ] Generated prompt is copyable.

### V7 - Reconstruction ⭐
- [ ] Selected checkpoint is accepted.
- [ ] Only same-session/history checkpoints at or before cutoff are used.
- [ ] Later checkpoint information is excluded.
- [ ] Stack/dependencies are reconstructed only from available evidence.
- [ ] Project structure is reconstructed only from available evidence.
- [ ] Decision log contains only supported decisions.
- [ ] Prompt is self-contained and copyable.
- [ ] UI says `UNVERIFIED` until fidelity verification exists.

### V8 - Two Agents
- [ ] Two sessions can appear simultaneously.
- [ ] Histories remain isolated.
- [ ] Updates do not overwrite the other agent.

### V9 - Collision
- [ ] Shared file/function is detected.
- [ ] Graph relationship is shown.
- [ ] False positive can be investigated from underlying evidence.

### V10 - Evidence Score
- [ ] Score is deterministic.
- [ ] Breakdown is visible.
- [ ] Missing evidence reduces confidence or produces N/A.

### V11 - Timeline
- [ ] Selecting a checkpoint changes the displayed state.
- [ ] Timeline and checkpoint list agree.

### V12 - Databricks
- [ ] Real permitted checkpoint data reaches Databricks.
- [ ] Retrieval returns real stored records.
- [ ] Aggregate is computed, not hardcoded.
- [ ] Removing Databricks removes/degrades the claimed historical functionality.

### V13 - Reconstruction Verification
- [ ] Fresh agent receives generated prompt.
- [ ] Reconstructed state is compared with source checkpoint.
- [ ] Fidelity result is reproducible.

### V14 - Replay
- [ ] Selected checkpoint can launch replay.
- [ ] Replay produces observable output/checkpoint.

## 3. Entire Graph Tests

- [ ] Use Graph for investigation before risky changes.
- [ ] Use Graph for impact analysis.
- [ ] Perform final semantic-diff review and verify conclusions against source/tests.

## 4. Noon Curveball Test

- [ ] Stable pre-noon checkpoint exists.
- [ ] Fresh Claude Code session uses earlier checkpoint context.
- [ ] Graph analysis informs the response.
- [ ] Smallest complete response is implemented.
- [ ] Tests pass.
- [ ] New checkpoint captures the response.

## 5. Failure Tests

- [ ] No checkpoint.
- [ ] Incomplete checkpoint.
- [ ] LLM unavailable.
- [ ] Graph unavailable.
- [ ] Insufficient reconstruction context.
- [ ] Reconstruction prompt generation failure.
- [ ] Databricks unavailable, once that version exists.

## 6. Manual Demo QA

Before the demo, run the complete highest stable version from scratch and verify the actual UI, not just API responses.
