# Agent Control Tower

> A checkpoint-native control room for supervising, understanding, recovering, and reconstructing AI coding agents.

## Build Approach

The project is built with **Claude Code using vertical scaling through working versions**. Each version preserves the previous one, adds a coherent capability, and is tested before the next version begins.

## Two Hero Features

### 1. Live Agent Control Tower

See AI coding agents live, inspect their objectives and activity, trace them through Entire Checkpoints, understand commits with an evidence-grounded LLM, and diagnose problems with Entire Graph.

### 2. Checkpoint Reconstruction

Treat a checkpoint as a recoverable development state. Select a checkpoint and generate a self-contained coding-agent prompt containing the stack, project structure, decisions, dependencies, and current state **up to that exact point**, while filtering out future checkpoint information.

The generated prompt is marked `UNVERIFIED` until replay/fidelity measurement is implemented.

## What It Does

- observes real Entire Checkpoint activity;
- visualizes one or more coding agents;
- inspects prompts, files, commits, tool activity, and checkpoint history;
- explains commits and agent progress using checkpoint evidence;
- detects STUCK/DONE/ON TRACK states;
- uses Entire Graph for structural impact analysis;
- generates checkpoint-grounded handoff prompts;
- reconstructs a selected checkpoint into a fresh-session prompt;
- later versions can detect cross-agent collisions, add evidence scores, historical Databricks memory, verification, and replay.

## Why Entire Is Essential

Entire Checkpoints are not an optional data source. They are the factual foundation for the product. The Control Tower's agent state, explanations, recovery prompts, and reconstruction context originate from checkpoint evidence.

Entire Graph adds structural evidence for impact analysis and, in later versions, cross-agent collision detection.

## Architecture

```text
Entire Checkpoints ──→ Ingestion ──→ Normalized Runtime State
                              │
Entire Graph ────────────────→│
                              ↓
                        Analysis Engine
                              ↓
                         Control Tower
                         /     |      \
                 Explain   Recover   Reconstruct
                              |         |
                           Handoff   Prompt Generator
```

Later versions add multi-agent collision detection, deterministic evidence scoring, Databricks historical memory, reconstruction verification, and replay.

## Version Roadmap

- V0 Foundation
- V1 Single Agent Control Tower
- V2 Agent Inspection
- V3 LLM Understanding
- V4 Status Intelligence
- V5 Entire Graph Intelligence
- V6 Handoff
- V7 Checkpoint Reconstruction ⭐
- V8 Two-Agent Live World
- V9 Agent Collision Detection
- V10 Evidence / Trust Layer
- V11 Checkpoint Timeline
- V12 Databricks Historical Memory
- V13 Reconstruction Verification
- V14 Replay
- V15+ Research Extensions

See `10_VERSION_ROADMAP.md` for the canonical roadmap.

## How to Run

### Prerequisites

- Git
- Node.js
- Python
- Entire CLI and required hackathon configuration
- LLM provider credentials as required by the implementation

### Development

Run the frontend and backend using the commands documented by the current implementation. Verify Entire Checkpoints are enabled before starting an agent session.

## Hackathon Requirements

### Entire

- [ ] Work begins from the required fork/mirror workflow.
- [ ] Entire Checkpoints enabled before agent-assisted development.
- [ ] Initial plan preserved.
- [ ] Pre-noon stable checkpoint preserved.
- [ ] Noon Curveball handled in a fresh session using earlier checkpoint context.
- [ ] Entire Graph used for investigation/impact analysis.
- [ ] Final conclusions verified against source/tests.

### Product

- [ ] Live agent observation works.
- [ ] Checkpoint inspection works.
- [ ] LLM interpretation is evidence-grounded.
- [ ] Graph-backed diagnosis works.
- [ ] Handoff works.
- [ ] Reconstruction Prompt Generator works.

### Best Use of Databricks

If V12 is completed:
- [ ] Working Databricks implementation.
- [ ] Databricks materially improves historical functionality.
- [ ] At least one aggregate is computed from real permitted data.
- [ ] Architecture and tradeoffs are reproducible.

## Limitations

- Reconstruction prompts are unverified until V13.
- Collision detection is limited by the Graph relationships the implementation can retrieve.
- Historical memory does not exist until V12.
- Replay does not exist until V14.
- Future versions are documented as roadmap items and should not be described as shipped functionality.

## What Makes This Different

This is not a generic agent dashboard. The system connects three layers:

```text
Checkpoint evidence
       +
Graph structure
       +
LLM interpretation
       ↓
Observable + explainable + recoverable agent work
```

The reconstruction feature adds a fourth idea: **development history can be turned back into a bounded, recoverable state.**

## Team

Add team information and submission links here.
