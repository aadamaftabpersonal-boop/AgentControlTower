# Agent Control Tower - Canonical Version Roadmap

## Philosophy

Agent Control Tower is built through **vertical scaling** with Claude Code.

A version is not a tier. It is a complete product increment.

```text
Vn
 ↓
Implement
 ↓
Test
 ↓
Real Entire experiment
 ↓
Review / checkpoint
 ↓
Vn+1
```

We can stop after any stable version and still have a coherent product.

## V0 - Foundation

Runnable frontend/backend, Claude Code workflow, Entire CLI, Checkpoints, configuration, tests.

## V1 - Single Agent Control Tower

Real checkpoint ingestion, normalized agent state, live Agent World, one observable agent.

## V2 - Agent Inspection

Objective, activity, files, commits, checkpoint trail, detail panel.

## V3 - LLM Understanding

Commit explanation, accomplishment summary, intent-vs-actual.

## V4 - Status Intelligence

ON TRACK, STUCK, DONE, optional DRIFTING, with evidence-backed reasons.

## V5 - Entire Graph Intelligence

Investigation, impact analysis, blast radius, Graph-backed diagnosis.

## V6 - Handoff

Checkpoint-grounded continuation prompt for a fresh agent.

## V7 - Checkpoint Reconstruction ⭐

Select checkpoint → hard historical cutoff → reconstruct stack/structure/decisions/current state → filter future context → generate self-contained prompt.

This is a hero feature alongside the Live Agent Control Tower.

## V8 - Two-Agent Live World

Two concurrent agents with isolated histories and live updates.

## V9 - Agent Collision Detection

Graph-backed detection of agents modifying related files/functions/execution paths.

## V10 - Evidence / Trust Layer

Deterministic evidence score with checkpoint, Graph, and test breakdown.

## V11 - Checkpoint Timeline

Interactive history tied to inspection and reconstruction.

## V12 - Databricks Historical Memory

Checkpoint-derived historical retrieval and cross-session aggregates with meaningful product impact.

## V13 - Reconstruction Verification

Fresh-agent replay and fidelity comparison against source checkpoint.

## V14 - Replay

One-click checkpoint replay in a fresh session.

## V15+

Findings-driven research extensions: delta-mode reconstruction, conceptual diffs, richer multi-agent coordination, automated recovery, and other capabilities discovered through real usage.

## Completion Rule

Never start the next version merely because it is exciting. Start it when the current version:

- runs;
- passes its important tests;
- preserves earlier behavior;
- has been exercised with real/controlled Entire evidence;
- has been checkpointed and reviewed.
