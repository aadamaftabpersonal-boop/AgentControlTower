# Agent Control Tower - Build Map / Implementation Blueprint

## 1. Build Philosophy

Build vertically with Claude Code. Each version is a complete runnable increment. Do not ask Claude Code to implement the entire roadmap in one pass.

```text
Current working version
        ↓
One coherent capability
        ↓
Tests + real experiment
        ↓
Checkpoint / review
        ↓
Next version
```

## 2. System Overview

```text
Entire Checkpoints ──→ Checkpoint Collector ──→ Normalizer ──→ Runtime State
                                                                    │
Entire Graph ───────→ Graph Client ────────────────────────────────┤
                                                                    ↓
                                                              Analysis Engine
                                                        ┌───────────┼───────────┐
                                                        ↓           ↓           ↓
                                                     Intent       Status      Evidence
                                                        │           │
                                                        └──────┬────┘
                                                               ↓
                                                               API
                                                               ↓
                                                         Control Tower
                                                               │
                               ┌────────────────────────────────┼─────────────────────┐
                               ↓                                ↓                     ↓
                         Understanding                     Recovery             Reconstruction
                         commit/status                       │                     │
                               │                         Handoff Prompt       Prompt Generator
                               └────────────────────────────┴─────────────────────┘
```

Later versions extend this with multi-agent collision detection, historical memory, verification, and replay.

## 3. Frontend Architecture

Recommended:
- React
- TypeScript
- Vite
- CSS modules or Tailwind CSS
- SSE client for live updates

Core components:
- `ControlTower`
- `AgentWorld`
- `AgentNode`
- `AgentDetailsPanel`
- `CommitInspector`
- `StatusBadge`
- `HandoffPanel`
- `CheckpointList`

Later components:
- `ReconstructionPromptPanel`
- `ConflictWarningBanner`
- `TrustScoreBadge`
- `CheckpointTimeline`
- `HistoricalMatchPanel`
- `AggregateInsightsPanel`

## 4. Backend Architecture

Recommended:
- Python
- FastAPI
- async processing where useful
- SSE for live updates

Core modules:
- `checkpoint_ingestor`
- `event_normalizer`
- `agent_registry`
- `analysis_service`
- `status_service`
- `commit_explainer`
- `handoff_service`
- `graph_service`

Later modules:
- `reconstruction_service`
- `conflict_service`
- `trust_score_service`
- `databricks_service`
- `fidelity_runner`
- `replay_service`

## 5. Core APIs

- `GET /api/agents`
- `GET /api/agents/{agent_id}`
- `GET /api/agents/{agent_id}/checkpoints`
- `GET /api/checkpoints/{checkpoint_id}`
- `GET /api/commits/{commit_id}/explanation`
- `GET /api/events`
- `POST /api/agents/{agent_id}/analyze`
- `POST /api/agents/{agent_id}/handoff`

Later APIs:
- `POST /api/checkpoints/{checkpoint_id}/reconstruction-prompt`
- `GET /api/conflicts`
- `GET /api/agents/{agent_id}/trust-score`
- `GET /api/history/similar`
- `GET /api/history/aggregates`
- reconstruction fidelity and replay endpoints

## 6. Canonical Version Build Order

### V0 - Foundation

Repository, app shell, Entire setup, configuration, test harness.

### V1 - Single Agent Control Tower

Real checkpoint ingestion → normalized state → live agent UI.

### V2 - Agent Inspection

Clickable agent → objective, files, commits, activity, checkpoint trail.

### V3 - LLM Understanding

Evidence-grounded commit explanation, accomplishment summary, intent-vs-actual.

### V4 - Status Intelligence

ON TRACK, STUCK, DONE, optional DRIFTING with evidence-backed reasons.

### V5 - Entire Graph Intelligence

Graph investigation, blast radius, structural diagnosis. Investigation and semantic-diff review should be used as engineering actions before risky changes, not merely UI decorations.

### V6 - Handoff

Generate a checkpoint-grounded continuation prompt for a fresh agent.

### V7 - Reconstruction ⭐

Select checkpoint → reconstruct state using only checkpoint and earlier evidence → generate self-contained coding-agent prompt. This is a hero feature.

### V8 - Two-Agent Live World

Run two concurrent agents and display both live.

### V9 - Collision Detection

Detect same/related files or functions and prove relationships with Graph.

### V10 - Evidence / Trust

Transparent deterministic score from checkpoint completeness, Graph verification, and tests.

### V11 - Timeline

Interactive checkpoint history and direct checkpoint selection for reconstruction.

### V12 - Databricks Historical Memory

Historical retrieval and cross-session aggregates that materially improve the product.

### V13 - Reconstruction Verification

Fresh agent reconstruction followed by state comparison/fidelity metrics.

### V14 - Replay

One-click replay from a selected checkpoint.

### V15+ - Research Extensions

Delta-mode reconstruction, conceptual diffs, richer coordination, automated recovery, and findings-driven extensions.

## 7. Reconstruction Prompt Generator

The generator must:

1. Accept a selected checkpoint.
2. Include that checkpoint and only earlier checkpoints from the same relevant session/history.
3. Reconstruct stack and dependencies known at that point.
4. Reconstruct file/directory structure.
5. Reconstruct decisions, assumptions, and rejected alternatives supported by evidence.
6. Describe the project state at the selected checkpoint.
7. Explicitly exclude facts first appearing after the selected checkpoint.
8. Produce one self-contained prompt suitable for a fresh coding-agent session.
9. Mark the result `UNVERIFIED` until replay/fidelity verification exists.

The most important correctness property is the **future-context filter**.

## 8. Definition of Done for Every Version

A version is complete only when:

- it runs locally;
- previous functionality still works;
- the new capability works end to end;
- tests cover important failure modes;
- real or controlled Entire evidence has been exercised;
- the version has been checkpointed and reviewed;
- Claude Code's implementation has not silently expanded into future versions.
