# Agent Control Tower - Design Spec / UI System

## 1. Design Direction

Visual language is inspired by the supplied AegisX architecture reference: technical poster/blueprint energy, cream graph-paper background, thick black outlines, cyan/pink/yellow/black blocks, condensed heavy typography, monospace system labels, pixel/retro technical icons, diagram connectors, arrows, warning strips, and modular technical boxes.

Do not recreate the reference deck. Translate its visual grammar into a live developer control room.

## 2. Visual Principles

- Cream graph-paper base.
- Heavy black borders.
- Strong cyan/pink/yellow/black accents.
- Condensed display typography for major labels.
- Monospace for system metadata.
- Sharp or minimally rounded technical modules.
- Diagram-like connectors and directional arrows.
- Warning/hazard strips for critical states.
- Dense information hierarchy without becoming unreadable.

Avoid:
- glassmorphism;
- purple AI gradients;
- generic rounded SaaS cards;
- excessive blur;
- decorative 3D effects.

## 3. Main Layout

```text
┌──────────────────────────────────────────────────────────────────┐
│ AGENT CONTROL TOWER                         ENTIRE // LIVE        │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│     AGENT WORLD                     SELECTED AGENT               │
│                                                                  │
│   [AGENT A]                       OBJECTIVE                      │
│      ●                              ...                          │
│                                                                  │
│               [AGENT B]          CURRENT ACTIVITY               │
│                    ●                 ...                         │
│                                                                  │
│                                   CHECKPOINT TRAIL               │
│                                   CP01 CP02 CP03 CP04            │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

## 4. Agent Node

Display:
- agent name;
- role;
- status;
- objective shorthand;
- latest checkpoint;
- current file/activity.

Use a strong visual distinction between ON TRACK, STUCK, DONE, and DRIFTING.

## 5. Agent Detail

Sections:
1. Objective
2. Current activity
3. Files touched
4. Commits
5. Checkpoint trail
6. Evidence
7. Analysis
8. Recovery actions

Recovery actions:
- `GENERATE HANDOFF`
- `RECONSTRUCT THIS CHECKPOINT`

## 6. Reconstruction Panel ⭐

This is a hero UI, not a secondary modal.

Header:
`CHECKPOINT RECONSTRUCTION`

Prominent selected checkpoint identifier and timestamp.

Context blocks:
- ORIGINAL OBJECTIVE
- PROJECT STRUCTURE
- DEPENDENCIES
- FILES / CHANGES
- DECISION LOG
- CURRENT STATE

Warning strip:
`FUTURE CONTEXT FILTERED`

Verification strip:
`UNVERIFIED - replay fidelity not yet measured`

Primary action:
`GENERATE RECONSTRUCTION PROMPT`

Output should be copyable as one clean prompt.

## 7. Handoff Panel

Show blocker, evidence, Graph impact, and next action before exposing the generated prompt.

## 8. Graph Evidence

Graph relationships should look like technical annotations rather than decorative charts. Example:

```text
validate_token()
      │ calls
      ▼
authenticate_request()
      │ used by
      ▼
14 API routes
```

## 9. Later Visual Components

- Conflict Warning Banner
- Evidence/Trust Badge
- Interactive Checkpoint Timeline
- Historical Match Panel
- Aggregate Insights Panel
- Replay/Fidelity Panel

## 10. Responsive Behavior

Desktop is primary. On smaller screens, stack Agent World above Agent Detail. Preserve the reconstruction prompt as a full-width readable surface.
